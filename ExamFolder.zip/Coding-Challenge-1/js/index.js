console.log("OK!")

API_KEY = "1";


//Print to HTML
function printResults(theJSON){
    let thereceivedJSON = theJSON;
    //Pending check of empty JSON!
    console.log(thereceivedJSON)

    if(thereceivedJSON.meals === null){
        let ErrorName = "No meals found!"
        let output = document.querySelector('.js-search-results');

        output.innerHTML = "";
    
        //Results of query
        output.innerHTML +=`
                <div>
                    <h2>
                        ${ErrorName}
                    </h2>
                </div>
                        `
        return
    }

    let mealName = "";
    let areaCuisine = "";
    let prepInst = "";
    let mealPic = "";


    //Get complete meal name  ------------ strMeal
    //Meal area cuisine ----------------- strArea
    //Meal's instructions of prep ----------- strInstructions
    //Meal's pic ------------- strMealThumb
    mealName = thereceivedJSON.meals[0].strMeal
    areaCuisine = thereceivedJSON.meals[0].strArea
    prepInst = thereceivedJSON.meals[0].strInstructions
    mealPic = thereceivedJSON.meals[0].strMealThumb

    //Target main js-search-results
    let output = document.querySelector('.js-search-results');

    output.innerHTML = "";

    //Results of query
    output.innerHTML +=`
            <div>
                <h2>
                    ${mealName}
                </h2>
            
                <h2>
                    ${areaCuisine}
                </h2>

                <p>
                    ${prepInst}
                </p>

                <div>
                    <img src=${mealPic} />
                </div>



            </div>
                    `


    
    
}

//Add event listener
function fetchFoods(searchKey){
    let url = `https://www.themealdb.com/api/json/v1/1/search.php?s=${searchKey}`;


    let settings = {
        method : 'GET'
    };

    console.log(url);


    //Time to print!
    fetch(url, settings)
        .then(response =>{
            if(response.ok){
                return response.json();
            }
            throw new Error(response.statusText);
        })
        .then(responseJSON => {
            printResults(responseJSON);
        })
        .catch(err => {
            console.log(err);
        });
};


function watchForm(){
    let submitBoton = document.querySelector('.submit-button-meal');
    submitBoton.addEventListener('click', (event) =>{
        event.preventDefault();
        let searchKey = document.querySelector('#query').value;
        fetchFoods(searchKey);
    });

}

//Initialize function

function init(){
    watchForm();
}

init();