const express = require( 'express' );
const bodyParser = require( 'body-parser' );
const mongoose = require( 'mongoose' );
const jsonParser = bodyParser.json();
const { DATABASE_URL, PORT } = require( './config' );

const app = express();

const {sports} = require ('.Coding-Challenge-2-and-3/models/sport-model.');

/* Your code goes here */


//Exercise 2)
app.delete('/sports/delete', (req, res) =>{
    let sportID = req.query.id;
    let sportIDbody = req.body.id;


    if(!sportID)
    {
        res.statusMessage="No ID for this sport was found";
        res.status(406).end();
    }
    if(sportID != sportIDbody)
    {
        res.statusMessage="IDs don't match";
        res.status(409).end();
    }


    //body and param

    if(!sportsID)
    {
        res.statusMessage="No ID for this sport was found";
        res.status(406).end();
    }

    sports
        .deleteSport(idSport)
        .then(result => {
            //Check if the result was different from zero
            if(result.deletedCount === 1)
            {
                res.status(204).end();
            }
            res.statusMessage = "ID doesn't belong to sport"
            res.status(404).end();
        })
        .catch(err => {
            res.statusMessage = err;
            return res.status(500).end();
        })

    //Only if conditions above were not met

})


app.listen( 8080, () => {
    console.log( "This server is running on port 8080" );
    new Promise( ( resolve, reject ) => {
        const settings = {
            useNewUrlParser: true, 
            useUnifiedTopology: true, 
            useCreateIndex: true
        };
        mongoose.connect( DATABASE_URL, settings, ( err ) => {
            if( err ){
                return reject( err );
            }
            else{
                console.log( "Database connected successfully." );
                return resolve();
            }
        })
    })
    .catch( err => {
        console.log( err );
    });
});