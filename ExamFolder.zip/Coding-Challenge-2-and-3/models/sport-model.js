const mongoose = require( 'mongoose' );
const uuid = require( 'uuid' );

/* Your code goes here */
const sportsSchema = mongoose.Schema({
        id : {
            type : String,
            unique : true,
            required : true
        },
        name : {
            type : String,
            required : true
        },
        num_players : {
            type : Number,
            required : true
        }
});

const sportsCollection = mongoose.model('sports', sportsSchema);

const sports = {
    //DELETE sports
    deleteSport : function(removeSport){
        return sportsCollection
        //Delete logic...
        .find(removeSport)
        .deleteOne()
        .then(completeDel => {
            return completeDel;
        })
        .catch(err =>{
            return err;
        });
    }
}


module.exports = {sports};